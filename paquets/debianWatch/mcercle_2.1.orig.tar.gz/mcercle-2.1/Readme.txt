mcercle est un logiciel de gestion libre pour PME et autoEntrepreneurs

-------------------------------------------------------

License: GPL
Author:  Cyril Frausti
website: http://frausti.fr/mcercle

-------------------------------------------------------

For installation, see INSTALL file.
